# edu-portal

1. Run backend service

To run backend use this command:

```
cd backend
npm run dev
```

2. Run frontend service

To run frontend use this command: 

```
cd frontend
yarn dev
```
